﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowLog : MonoBehaviour {

	public void ShowLogPanel()
    {
        LogPanel.Show();
    }
}
