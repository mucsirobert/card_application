﻿using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour {


	/*public void MoveCameraToTable(Player player)
    {
        var players = Player.Players;

        foreach (var p in players)
        {
            if (!p.isLocalPlayer)
                p.MoveTableToBack();
        }

        player.MoveTableToFront();

        transform.DOMove(new Vector3(0, 10, -10), 0.5f);


    }

    public void MoveToCenter()
    {
        transform.DOMove(new Vector3(0, 0, -10), 0.5f);
    }

    public void MoveTownTable()
    {
        transform.DOMove(new Vector3(0, -10, -10), 0.5f);
    }*/
}
