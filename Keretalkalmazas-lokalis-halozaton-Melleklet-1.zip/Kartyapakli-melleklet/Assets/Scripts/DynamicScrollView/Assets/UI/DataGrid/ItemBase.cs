﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemBase : MonoBehaviour
{
    //TODO make it nicer, don't use object parameter here
    public virtual void SetData(object o)
    {
        
    }

}
