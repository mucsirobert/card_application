﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SettingsMenu : Dialog<SettingsMenu> {

   /* public static void Show() {
        Create(MenuManager.Instance.deckSettingsPrefab);
    }*/


}
